Iron Eddic Font 1.0 by Tracy Barnett and Xander Oernstein

Published under a Creative Commons 4.0 Attribution (CC-BY) License

This is a basic substitution font for the standard English alphabet. Not all letters are represented.

C and K are a single glyph, under C
For Q, use CE
For Y, use I or EU, depending on the sound you are trying to replicate.
For X, use Z

For numbers, spell out the name of the number.

The lowercase versions of the runes are the standard orientations. The merkstaves of the runes are the capitalized versions.

This is a first draft and may be updated with additional glyphs as time goes on.


----------NOTE----------
This font is not for use in any projects that promote or suport racism, bigotry, white supremacy, white nationalism, or any similar ideologies. If you ascribe to any of these ideologies, you are not permitted or welcome to use this font in any of your projects.